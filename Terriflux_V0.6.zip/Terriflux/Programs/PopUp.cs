﻿using Godot;

namespace Terriflux.Programs
{
    public static class PopUp
    {
        public static void Say(string message)
        {
            GD.Print(message);
        }
    }
}
