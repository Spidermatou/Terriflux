namespace Terriflux.Programs.Model.Cell
{
    public enum CellKind
    {
        BUILDING,
        WASTELAND // free cell 
    }
}
