namespace Terriflux.Programs.Model.Placeables
{
    /// <summary>
    /// Scale of influence of a structur.
    /// </summary>
    public enum InfluenceScale
    {
        REGIONAL,
        NATIONAL,
        WORLDWIDE
    }
}