namespace Terriflux.Programs.Model.Placeables
{
    public enum FlowKind
    {
        NOTHING, // error kind
        ENERGY,
        RAW_MATERIAL,
        WOOD,
        WATER,
        CEREALS,
        MANUFACTURED_MERCHANDISE,
        MEDICATIONS,
        BREAD
    }
}