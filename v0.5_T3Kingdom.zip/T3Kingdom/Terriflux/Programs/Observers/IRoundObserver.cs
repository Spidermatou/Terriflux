﻿namespace Terriflux.Programs.Observers
{
    public interface IRoundObserver
    {
        void Update(int roundNumber);
    }
}