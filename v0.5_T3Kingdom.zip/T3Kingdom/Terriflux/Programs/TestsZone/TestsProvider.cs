﻿using Godot;
using System.Collections.Generic;
using System.Text;
using Terriflux.Programs.Controller;
using Terriflux.Programs.Exceptions;
using Terriflux.Programs.Factories;
using Terriflux.Programs.GameContext;
using Terriflux.Programs.Gauges;
using Terriflux.Programs.Model.Cell;
using Terriflux.Programs.Model.Grid;
using Terriflux.Programs.Model.Placeables;
using Terriflux.Programs.Model.Round;
using Terriflux.Programs.View;

namespace Terriflux.Programs.TestsZone
{
    public partial class TestsProvider
    {
        private readonly Node scene;

        public TestsProvider(Node scene)
        {
            this.scene = scene;
        }

        private void PrintChildrenCount()
        {
            StringBuilder sb = new();
            List<Node> children = new(scene.GetChildren());

            sb.Append(children[0].ToString());
            for (int i = 1; i < scene.GetChildren().Count; i++)
            {
                sb.Append(',')
                  .Append(children[i].ToString());
            }

            GD.Print($"Nb of children in this scene: {scene.GetChildren().Count} ({sb}).");
        }

        // Models
        public static void TCellModel()
        {
            CellModel cm = new("Default", CellKind.WASTELAND);
            GD.Print($"Null? {cm == null}");
            GD.Print($"Attributes (2): ");
            GD.Print(cm.GetName());
            GD.Print(cm.GetKind());
        }

        public static void TGrassModel()
        {
            GrassModel grass = new();
            GD.Print($"Null? {grass == null}");
            GD.Print($"Attributes (2): ");
            GD.Print(grass.GetName());
            GD.Print(grass.GetKind());
        }


        public static void TBuildingModel()
        {
            // attributes
            string name = "Fork Factory";
            double[] impacts = new double[3] { 12.4, 23.0, 11.8 };
            InfluenceScale influence = InfluenceScale.NATIONAL;
            Dictionary<FlowKind, int> needs = new()
            {
                { FlowKind.WATER, 3 },
                { FlowKind.ENERGY, 7 },
                { FlowKind.RAW_MATERIAL, 4 }
            };
            Dictionary<FlowKind, int> productions = new()
            {
                { FlowKind.MANUFACTURED_MERCHANDISE, 5 }
            };

            // create the building himself
            BuildingModel bm = new(name, impacts, influence, needs, productions);

            // print
            GD.Print($"Null? {bm == null}");
            GD.Print($"Attributes (6): ");
            GD.Print(bm.GetName());
            GD.Print(bm.GetInfluence());
            // needs
            GD.Print("Needs-");
            foreach (FlowKind flow in bm.GetNeedsKind())
            {
                GD.Print($"\t*Flow:{flow}, Qty:{bm.GetQuantityNeeded(flow)}");
            }
            // products
            GD.Print("Products-");
            foreach (FlowKind flow in bm.GetProductionKind())
            {
                GD.Print($"\t*Flow:{flow}, Qty:{bm.GetQuantityProduced(flow)}");
            }
        }

        public static void TGridModel()
        {
            int wantedSize = 10;
            GridModel grid = new(wantedSize);

            GD.Print($">> Grid full of grass' part <<");
            GD.Print($"Is null? {grid == null}");
            GD.Print($"Size: {grid.GetSize()}, expected {wantedSize}");

            for (int line = 0; line < grid.GetSize(); line++)
            {
                for (int column = 0; column < grid.GetSize(); column++)
                {
                    grid.PlaceAt(new GrassModel(), line, column);
                    GD.Print(grid.GetPlaceableAt(line, column));
                }
            }

            // self
            GD.Print(grid.Verbose());

            // placeable
            string name = "Fork Factory";
            double[] impacts = new double[3] { 12.4, 23.0, 11.8 };
            InfluenceScale influence = InfluenceScale.NATIONAL;
            Dictionary<FlowKind, int> needs = new()
            {
                { FlowKind.WATER, 3 },
                { FlowKind.ENERGY, 7 },
                { FlowKind.RAW_MATERIAL, 4 }
            };
            Dictionary<FlowKind, int> productions = new()
            {
                { FlowKind.MANUFACTURED_MERCHANDISE, 5 }
            };
            Vector2I coordinatesBuilding1 = new(2, 4);
            Vector2I coordinatesBuilding2 = new(6, 3);

            GD.Print($">> Grid with placeables part <<");
            grid.PlaceAt(new BuildingModel(name, impacts, influence, needs, productions),
                coordinatesBuilding1.X, coordinatesBuilding1.Y);    // add building in 2,4 (horizontal)
            grid.PlaceAt(new BuildingModel(name, impacts, influence, needs, productions),
                6, 3);        // add building in 6,3 (vertical)
            GD.Print($"Is a placeable in {coordinatesBuilding1.X},{coordinatesBuilding1.Y} and not null? " +
                $"{grid.GetPlaceableAt(coordinatesBuilding1.X, coordinatesBuilding1.Y) == null}");
            GD.Print($"Is a placeable in {coordinatesBuilding2.X},{coordinatesBuilding2.Y} and not null? " +
                $"{grid.GetPlaceableAt(coordinatesBuilding2.X, coordinatesBuilding2.Y) == null}");
            GD.Print($"What's repertoried (placeables)?");
            foreach (KeyValuePair<Vector2I, IPlaceable> kvp in grid.GetAllPlacements())
            {
                GD.Print($"Key=({kvp.Key.X},{kvp.Key.Y}) and Value={nameof(kvp.Value)}.");
            }
        }

        // Views
        public void TCellView(bool print = false)
        {
            CellView view = CellView.Design();
            scene.AddChild(view);
            PrintChildrenCount();

            if (print == false)
            {
                view.Hide();
            }
        }

        public void TGrassView(bool print = false)
        {
            GrassView view = GrassView.Design();
            scene.AddChild(view);
            PrintChildrenCount();

            if (print == false)
            {
                view.Hide();
            }
        }

        public void TBuildingView(bool print = false)
        {
            const string TNAME = "Default";
            string TPATH = OurPaths.TEXTURES + "default.png";

            // create the model
            BuildingModel tmodel = new(TNAME,
               new double[3],
               InfluenceScale.REGIONAL,
               new Dictionary<FlowKind, int>(),
               new Dictionary<FlowKind, int>());

            // create the view
            Texture2D texture = GD.Load<Texture2D>(TPATH);
            BuildingView view = BuildingView.Design(tmodel, texture);

            // add to scene
            scene.AddChild(view);

            // print, etc
            PrintChildrenCount();

            if (print == false)
            {
                view.Hide();
            }
        }

        // Factories   
        public void TBuildingFactory(bool print = false)
        {
            BuildingModel model = BuildingFactory.LoadModel("field", InfluenceScale.NATIONAL);

            GD.Print($">> Building model part <<");
            GD.Print(model.Verbose());

            GD.Print($">> Grid with placeables part <<");
            BuildingView view = BuildingFactory.CreateView(model);
            scene.AddChild(view);
            PrintChildrenCount();

            if (print == false)
            {
                view.Hide();
            }
        }

        public void TBuildingFactory_WithUnprovidedTexture(bool print = false)
        {
            BuildingModel model = BuildingFactory.LoadModel("fork factory", InfluenceScale.NATIONAL);

            GD.Print($">> Building model part <<");
            GD.Print(model.Verbose());

            GD.Print($">> Grid with placeables part <<");
            BuildingView view = BuildingFactory.CreateView(model);
            scene.AddChild(view);
            PrintChildrenCount();

            if (print == false)
            {
                view.Hide();
            }
        }


        public void TGridFactory_GrassOnly(Vector2 startPosition, bool print = false)
        {
            GridModel model = GridFactory.CreateWasteland(5);

            GD.Print($">> A grid full grass <<");
            GD.Print(model.Verbose());

            GD.Print($">> Grid with placeables part <<");
            GridView view = GridFactory.CreateView(model);
            view.Position = startPosition;
            scene.AddChild(view);

            if (print == false)
            {
                view.Hide();
            }
        }

        public void TGridFactory_WithBuildings(Vector2 startPosition, bool print = false)
        {
            GridModel model = GridFactory.CreateWasteland(10);

            GD.Print($">> A grid with buildings <<");
            BuildingModel tbuildingModel1 = BuildingFactory.LoadModel("fork factory", InfluenceScale.NATIONAL);
            BuildingModel tbuildingModel2 = BuildingFactory.LoadModel("field", InfluenceScale.REGIONAL);
            model.PlaceAt(tbuildingModel1, 3, 5);
            model.PlaceAt(tbuildingModel2, 0, 0);
            GD.Print(model.Verbose());

            GD.Print($">> Grid with placeables part <<");
            GridView view = GridFactory.CreateView(model);
            view.Position = startPosition;
            view.Scale = new Vector2((float)0.5, (float)0.5);
            scene.AddChild(view);

            if (print == false)
            {
                view.Hide();
            }
        }

        public void TGridFactory_WithConflicts(Vector2 startPosition, bool print = false)
        {
            GridModel model = GridFactory.CreateWasteland(5);

            GD.Print($">> A grid with buildings (and conflicts) <<");
            BuildingModel tbuildingModel = BuildingFactory.LoadModel("field", InfluenceScale.REGIONAL);
            model.PlaceAt(tbuildingModel, 0, 0);

            try { model.PlaceAt(tbuildingModel, 0, 0); } // try to place at the same case
            catch (UnplaceableException e) { GD.Print($"CATCHED: {e.Message}"); }

            GD.Print(model.Verbose());

            GD.Print($">> Grid with placeables part (and conflicts)  <<");
            GridView view = GridFactory.CreateView(model);
            view.Position = startPosition;
            scene.AddChild(view);

            if (print == false)
            {
                view.Hide();
            }
        }

        public void TPlacementListView(Vector2 spawnPosition, bool print = false)
        {
            // design it
            PlacementList placementList = PlacementList.Design();
            placementList.Position = spawnPosition;
            scene.AddChild(placementList);

            // verbose
            GD.Print(placementList.Verbose());
            PrintChildrenCount();

            // hide?
            if (!print)
            {
                placementList.Hide();
            }
        }

        public void TClickableGridView(Vector2 gridSpawnPosition, Vector2 placementListSpawnPosition, bool print = false)
        {
            // design it
            PlacementList placementList = PlacementList.Design();
            placementList.Position = placementListSpawnPosition;
            scene.AddChild(placementList);

            // assign grid to controller
            GridModel gridModel = GridFactory.CreateWasteland(5);
            GridController.SetGrid(gridModel);
            GridView gridView = GridFactory.CreateView(gridModel);
            gridView.Position = gridSpawnPosition;
            gridView.Scale = new Vector2((float)0.5, (float)0.5);
            gridModel.AddObserver(gridView);
            scene.AddChild(gridView);

            // verbose
            GD.Print(placementList.Verbose());
            PrintChildrenCount();

            // hide?
            if (!print)
            {
                placementList.Hide();
            }
        }

        public static void TRoundModel()
        {
            RoundModel mod = new();
            GD.Print(mod.Verbose());
            GD.Print(">> Build x 3");
            mod.PlusOneBuilded();
            mod.PlusOneBuilded();
            mod.PlusOneBuilded();
            GD.Print(">> Get infos");
            GD.Print("This turn:" + mod.GetThisTurn());
            GD.Print("Max per turn:" + mod.GetMaxPerTurn());
            GD.Print("Round numb:" + mod.GetRoundNumber());
            GD.Print(">>Next turn");
            mod.NextTurn();
            GD.Print(mod.Verbose());
        }

        public void TRoundView(bool print = false)
        {
            RoundCounter view = RoundCounter.Design();
            scene.AddChild(view);
            view.Show();

            RoundModel model = new();
            model.AddObserver(view);

            // hide?
            if (!print)
            {
                view.Hide();
            }
            // more test
            else
            {
                GD.Print(">> Infos");
                GD.Print(model.Verbose());
                GD.Print(">> Now, we build something");
                model.PlusOneBuilded();
                GD.Print(model.Verbose());
                GD.Print(">> Next turn!");
                model.NextTurn();
                GD.Print(model.Verbose());
                GD.Print(">> Now, we try to build too much");
                try
                {
                    for (int i = 0; i < model.GetMaxPerTurn() + 1; i++)
                    {
                        model.PlusOneBuilded();
                    }

                    // nothing catched?
                    GD.Print("Uh oh... no conflict detected!");
                }
                catch
                {
                    GD.Print("Exception catched successfully!");
                }
            }
        }

        public void TRoundController(bool print = false)
        {
            RoundCounter view = RoundCounter.Design();
            scene.AddChild(view);
            view.Show();

            RoundModel model = new();

            RoundController.SetModel(model);
            RoundController.SetView(view);

            // hide?
            if (!print)
            {
                view.Hide();
            }
            // more test
            else
            {
                GD.Print(">> Infos");
                GD.Print(model.Verbose());
            }
        }

        public void TImpacts(bool print = false)
        {
            Impacts myimp = Impacts.Design();
            scene.AddChild(myimp);
            myimp.Show();

            myimp.AddSocial(75);

            // hide?
            if (!print)
            {
                myimp.Hide();
            }
            // more test
            else
            {
                GD.Print(">> Change social to 75%");
                myimp.AddSocial(75);
            }
        }

        public void TImpactsController(Vector2 gridSpawnPosition,
            Vector2 placementListSpawnPosition,
            Vector2 roundsSpawnPosition,
            Vector2 impactsSpawnPosition,
            bool print = false)
        {
            // create impacts
            Impacts impacts = Impacts.Design();
            impacts.Position = impactsSpawnPosition;
            impacts.Show();
            scene.AddChild(impacts);

            // create placementList
            PlacementList placementList = PlacementList.Design();
            placementList.Position = placementListSpawnPosition;
            placementList.Show();
            scene.AddChild(placementList);

            // create grid
            GridModel gridModel = GridFactory.CreateWasteland(5);
            GridView gridView = GridFactory.CreateView(gridModel);
            gridView.Position = gridSpawnPosition;
            gridView.Scale = new Vector2((float)0.5, (float)0.5);
            gridView.Show();
            gridModel.AddObserver(gridView);
            scene.AddChild(gridView);

            // create rounds
            RoundModel roundModel = new();
            RoundCounter roundCounter = RoundCounter.Design();
            roundCounter.Position = roundsSpawnPosition;
            roundCounter.Show();
            roundModel.AddObserver(roundCounter);
            scene.AddChild(roundCounter);

            // assign grid and impacts to controller
            GridController.SetControledImpacts(impacts);
            GridController.SetGrid(gridModel);
            GridController.SetRoundManager(roundModel);

            // verbose
            GD.Print(GridController.Verbose());

            // hide?
            if (!print)
            {
                gridView.Hide();
                placementList.Hide();
                impacts.Hide();
            }
        }

        // inventory
        public async void TInvetoryTable(Vector2 position, bool show = false)
        {
            Inventory inv = Inventory.Design();
            SceneTreeTimer timer;

            if (show)
            {
                inv.Position = position;
                this.scene.AddChild(inv);
            }
            
            // view tests
            GD.Print(">>Add 4 water");
            inv.Add(FlowKind.WATER, 4);
            // wait 2 s
            timer = this.scene.GetTree().CreateTimer(2.0f); 
            await this.scene.ToSignal(timer, "timeout");
            GD.Print(">>Remove 4 water");
            inv.Remove(FlowKind.WATER, 4);
            // wait 2 s
            timer = this.scene.GetTree().CreateTimer(2.0f);
            await this.scene.ToSignal(timer, "timeout");

            // values test
            GD.Print(">>Remove 45 energies");
            inv.Remove(FlowKind.ENERGY, 45);
            GD.Print(">>Enough energy if I want 2 energies?");
            GD.Print(inv.ContainsEnough(FlowKind.ENERGY, 2));
            GD.Print(">>Add 3 MANUFACTURED_MERCHANDISE");
            inv.Add(FlowKind.MANUFACTURED_MERCHANDISE, 4);
            GD.Print(">>Enough MANUFACTURED_MERCHANDISE if I want 2? (supposed yes)");
            GD.Print(inv.ContainsEnough(FlowKind.MANUFACTURED_MERCHANDISE, 2));
            GD.Print(">> ...and 0? (supposed yes)");
            GD.Print(inv.ContainsEnough(FlowKind.MANUFACTURED_MERCHANDISE, 0));
            GD.Print(">> ...and 63? (supposed yes)");
            GD.Print(inv.ContainsEnough(FlowKind.MANUFACTURED_MERCHANDISE, 63));
        }
    }
}
