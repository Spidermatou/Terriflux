namespace Terriflux.Programs.Model.Cell
{
    public partial class GrassModel : CellModel
    {
        public GrassModel() : base("Grass", CellKind.WASTELAND) { }
    }
}