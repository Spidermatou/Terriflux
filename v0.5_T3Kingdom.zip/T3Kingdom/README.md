# T3

## Equipe
- FERNANDES Samuel
- LE ROUX Aymeric
- GILLIG Mattéo
- Tejedinne

## Tâches 
### Prioritaires (obligatoires)
[] jauges (format mvc)              ~ en cours(aymeric)
[x] cellules et du terrain          ~ sam 
[x] bâtiments                       ~ sam (ajouts poss)
[] assets                           ~ tejedinne
[x] conception de posters           ~ mattéo
[] inventaire à flux                  
[x] fluxs                           ~ sam (ajouts poss)
[] hud placement bâtiments  {2}     ~ sam EN COURS

### Secondaires
[] evènements "aléatoires" où le joueur répond oui/non (présenté par un pnj?)
[] inventaire "dynamique"  {1}

### Notes de tâches
{1} flèche rouge vers le haut de l'inventaire pour dire qu'au prochain tour plus de flux sortant que de flux rentrants, une barre grise horizontale pour dire qu'il y aura autant d'entrées que de sortie, et flèche verte vers le bas de l'inventaire si plus de flux entrant que de sortants

{2} liste affichée dans l'écran principal, cliquable, pour que l'utilisateur créer rapidement un bâtiment spécifique 